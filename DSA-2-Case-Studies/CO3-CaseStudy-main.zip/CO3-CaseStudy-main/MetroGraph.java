import java.util.*;

class Edge {
    int src, dest, weight;

    Edge(int s, int d, int w) {
        src = s;
        dest = d;
        weight = w;
    }
}

public class MetroGraph {

    int V;
    List<Edge> edges = new ArrayList<>();
    int[] parent, rank;

    MetroGraph(int v) {
        V = v;
        parent = new int[v];
        rank = new int[v];

        for (int i = 0; i < v; i++)
            parent[i] = i;
    }

    int find(int x) {
        if (parent[x] != x)
            parent[x] = find(parent[x]);
        return parent[x];
    }

    boolean union(int a, int b) {

        int pa = find(a);
        int pb = find(b);

        if (pa == pb)
            return false;

        if (rank[pa] < rank[pb])
            parent[pa] = pb;
        else if (rank[pa] > rank[pb])
            parent[pb] = pa;
        else {
            parent[pb] = pa;
            rank[pa]++;
        }

        return true;
    }

    void kruskalMST() {

        edges.sort((a, b) -> a.weight - b.weight);

        int cost = 0;

        System.out.println("\nMST Edges:");

        for (Edge e : edges) {

            if (union(e.src, e.dest)) {

                System.out.println(
                        e.src + " -- " + e.dest + " : " + e.weight + " km");

                cost += e.weight;
            }
        }

        System.out.println("Total MST Cost: " + cost + " km");
    }

    public static void main(String[] args) {

        MetroGraph g = new MetroGraph(6);

        g.edges.add(new Edge(0, 1, 4));
        g.edges.add(new Edge(1, 2, 2));
        g.edges.add(new Edge(2, 3, 3));
        g.edges.add(new Edge(3, 4, 5));
        g.edges.add(new Edge(4, 5, 7));

        System.out.println("========================================");
        System.out.println(" BANGALORE METRO GRAPH SYSTEM ");
        System.out.println("========================================");

        g.kruskalMST();

        System.out.println("\nTime Complexity:");
        System.out.println("Kruskal MST : O(E log E)");
    }
}